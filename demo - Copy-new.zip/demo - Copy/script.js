/* ============ ADMIN API CONFIGURATION ============ */
// Use relative URLs so it works both via the Flask server (same origin) and file:// protocol
const ADMIN_API_BASE = window.location.origin + '/api';
const ADMIN_API_HOST = window.location.origin;

/* ============ LOAD DYNAMIC SITE CONTENT ============ */
(async function() {
    try {
        const res = await fetch(`${ADMIN_API_BASE}/site-content`);
        const content = await res.json();
        
        // Update hero section
        if (content.hero_title) {
            const heroTitle = document.querySelector('.hero h1');
            if (heroTitle) heroTitle.textContent = content.hero_title;
        }
        if (content.hero_subtitle) {
            const heroSubtitle = document.querySelector('.hero .eyebrow');
            if (heroSubtitle) heroSubtitle.textContent = content.hero_subtitle;
        }
        if (content.hero_description) {
            const heroDesc = document.querySelector('.hero-copy');
            if (heroDesc) heroDesc.textContent = content.hero_description;
        }
        
        // Update about section
        if (content.about_title) {
            const aboutTitle = document.querySelector('#about h2');
            if (aboutTitle) aboutTitle.textContent = content.about_title;
        }
        if (content.about_text) {
            const aboutText = document.querySelector('#about p');
            if (aboutText) aboutText.textContent = content.about_text;
        }
        
        // Update stats
        const statKeys = ['stats_menu', 'stats_formats', 'stats_service', 'stats_support'];
        const statLabels = ['stats_menu_label', 'stats_formats_label', 'stats_service_label', 'stats_support_label'];
        const statEls = document.querySelectorAll('.quick-stats strong');
        const statLabelEls = document.querySelectorAll('.quick-stats span');
        
        statKeys.forEach((key, i) => {
            if (content[key] && statEls[i]) {
                statEls[i].textContent = content[key];
            }
        });
        statLabels.forEach((key, i) => {
            if (content[key] && statLabelEls[i]) {
                statLabelEls[i].textContent = content[key];
            }
        });
        
        // Update contact info
        if (content.contact_phone) {
            const phoneEl = document.querySelector('.info-card .info-value');
            if (phoneEl) phoneEl.textContent = content.contact_phone;
        }
        if (content.contact_email) {
            const emailEls = document.querySelectorAll('.info-card .info-value');
            if (emailEls[1]) emailEls[1].textContent = content.contact_email;
        }
        if (content.contact_website) {
            const websiteEls = document.querySelectorAll('.info-card .info-value');
            if (websiteEls[2]) websiteEls[2].textContent = content.contact_website;
        }
        if (content.contact_response) {
            const responseEls = document.querySelectorAll('.info-card .info-value');
            if (responseEls[3]) responseEls[3].textContent = content.contact_response;
        }
        
        // Update footer
        if (content.footer_text) {
            const footerText = document.querySelector('.footer-brand p');
            if (footerText) footerText.textContent = content.footer_text;
        }
    } catch (e) {
        console.log('Could not load dynamic content from admin API. Using static content.');
    }
})();

/* ============ LOAD DYNAMIC NAVBAR LINKS ============ */
(async function() {
    try {
        const res = await fetch(`${ADMIN_API_BASE}/navbar-links`);
        const links = await res.json();
        
        if (links && links.length > 0) {
            const nav = document.querySelector('.main-nav');
            if (nav) {
                const darkToggle = nav.querySelector('.dark-toggle');
                nav.querySelectorAll('a').forEach(a => a.remove());
                
                links.forEach(link => {
                    const a = document.createElement('a');
                    a.href = link.href;
                    a.textContent = link.label;
                    nav.appendChild(a);
                });
                
                if (darkToggle) {
                    nav.appendChild(darkToggle);
                }
                
                nav.querySelectorAll('a').forEach(link => {
                    link.addEventListener('click', () => {
                        const navToggle = document.querySelector('.nav-toggle');
                        if (navToggle) {
                            nav.classList.remove('is-open');
                            navToggle.setAttribute('aria-expanded', 'false');
                        }
                    });
                });
            }
        }
    } catch (e) {
        console.log('Could not load navbar links from admin API. Using static links.');
    }
})();

/* ============ LOAD DYNAMIC GALLERY ============ */
(async function() {
    try {
        const res = await fetch(`${ADMIN_API_BASE}/gallery`);
        const images = await res.json();
        
        if (images && images.length > 0) {
            const galleryGrid = document.querySelector('.gallery-grid');
            if (galleryGrid) {
                // Clear existing static gallery items first so uploaded images are shown
                galleryGrid.innerHTML = '';
                
                images.forEach((image, index) => {
                    const delay = (index % 3) + 1;
                    const item = document.createElement('div');
                    item.className = `gallery-item animate-on-scroll fade-scale delay-${delay}`;
                    const imgSrc = `${ADMIN_API_HOST}/static/${image.image_path}`;
                    item.innerHTML = `
                        <img src="${imgSrc}" alt="${image.title}">
                        <div class="gallery-overlay"><span>${image.title}</span></div>
                    `;
                    galleryGrid.appendChild(item);
                });
            }
        }
    } catch (e) {
        console.log('Could not load gallery from admin API. Using static gallery.');
    }
})();

/* ============ LOAD DYNAMIC TESTIMONIALS ============ */
(async function() {
    try {
        const res = await fetch(`${ADMIN_API_BASE}/testimonials`);
        const testimonials = await res.json();
        
        if (testimonials && testimonials.length > 0) {
            const testimonialGrid = document.querySelector('.testimonial-grid');
            if (testimonialGrid) {
                testimonialGrid.innerHTML = '';
                
                testimonials.forEach((t, index) => {
                    const delay = (index % 3) + 1;
                    const stars = '⭐'.repeat(t.rating);
                    const avatarUrl = t.avatar_path 
                        ? `${ADMIN_API_HOST}/static/${t.avatar_path}`
                        : `https://ui-avatars.com/api/?name=${encodeURIComponent(t.name)}&background=26624a&color=fff&size=200`;
                    
                    const blockquote = document.createElement('blockquote');
                    blockquote.className = `animate-on-scroll delay-${delay}`;
                    blockquote.innerHTML = `
                        <div class="testimonial-avatar">
                            <img src="${avatarUrl}" alt="${t.name}">
                        </div>
                        <p>"${t.content}"</p>
                        <div class="testimonial-stars">${stars}</div>
                        <cite>${t.name}${t.role ? ', ' + t.role : ''}</cite>
                    `;
                    testimonialGrid.appendChild(blockquote);
                });
            }
        }
    } catch (e) {
        console.log('Could not load testimonials from admin API. Using static testimonials.');
    }
})();

/* ============ NAVBAR TOGGLE ============ */
const navToggle = document.querySelector('.nav-toggle');
const mainNav = document.querySelector('.main-nav');

if (navToggle && mainNav) {
    navToggle.addEventListener('click', () => {
        const isOpen = mainNav.classList.toggle('is-open');
        navToggle.setAttribute('aria-expanded', String(isOpen));
    });

    mainNav.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', () => {
            mainNav.classList.remove('is-open');
            navToggle.setAttribute('aria-expanded', 'false');
        });
    });
}

/* ============ NAVBAR SCROLL EFFECT ============ */
const header = document.querySelector('.site-header');

if (header) {
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });
}

/* ============ SCROLL ANIMATIONS ============ */
const animateElements = document.querySelectorAll('.animate-on-scroll');

if (animateElements.length > 0) {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, {
        threshold: 0.12,
        rootMargin: '0px 0px -40px 0px'
    });

    animateElements.forEach(el => observer.observe(el));
}

/* ============ FORM HANDLING ============ */
const franchiseForm = document.getElementById('franchiseForm');
const formMessage = document.getElementById('formMessage');

if (franchiseForm && formMessage) {
    franchiseForm.addEventListener('submit', async (event) => {
        event.preventDefault();

        const name = document.getElementById('name').value.trim();
        const mobile = document.getElementById('mobile').value.trim();
        const email = document.getElementById('email').value.trim();
        const city = document.getElementById('city').value.trim();
        const budget = document.getElementById('budget').value;
        const message = document.getElementById('message').value.trim();

        const submitBtn = franchiseForm.querySelector('button[type="submit"]');
        const originalBtnText = submitBtn.textContent;
        submitBtn.textContent = '⏳ Sending...';
        submitBtn.disabled = true;

        try {
            await fetch(`${ADMIN_API_BASE}/submit-inquiry`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    name, mobile, email, city, budget,
                    message: message || 'No additional message'
                })
            });
        } catch (error) {
            console.warn('Could not save inquiry to database:', error);
        }

        formMessage.innerHTML = `
            <span class="thank-emoji">🙏</span>
            <span class="thank-heading">Thank You, ${name}!</span>
            <span class="thank-detail">We have received your inquiry for <strong>${city}</strong> under the <strong>${budget}</strong> plan.</span>
            <span class="thank-detail">Our franchise team will reach out to you at <strong>${mobile}</strong> or <strong>${email}</strong> within 24 hours.</span>
            <span class="thank-veg">🌱 100% Veg Restaurant • Fresh & Healthy</span>
        `;
        formMessage.classList.add('show');
        formMessage.scrollIntoView({ behavior: 'smooth', block: 'center' });

        franchiseForm.reset();
        submitBtn.textContent = originalBtnText;
        submitBtn.disabled = false;

        setTimeout(() => {
            formMessage.classList.remove('show');
        }, 20000);
    });
}

/* ============ GALLERY LIGHTBOX ============ */
(function() {
    function initLightbox() {
        const galleryItems = document.querySelectorAll('.gallery-item');
        if (galleryItems.length === 0) return;

        let lightbox = document.querySelector('.lightbox');
        if (!lightbox) {
            lightbox = document.createElement('div');
            lightbox.className = 'lightbox';
            lightbox.setAttribute('role', 'dialog');
            lightbox.setAttribute('aria-label', 'Image viewer');
            lightbox.innerHTML = `
                <button class="lightbox-close" aria-label="Close">&times;</button>
                <button class="lightbox-prev" aria-label="Previous image">&#8249;</button>
                <button class="lightbox-next" aria-label="Next image">&#8250;</button>
                <div class="lightbox-content">
                    <img src="" alt="">
                    <div class="lightbox-caption"></div>
                </div>
            `;
            document.body.appendChild(lightbox);
        }

        const lightboxImg = lightbox.querySelector('img');
        const lightboxCaption = lightbox.querySelector('.lightbox-caption');
        const closeBtn = lightbox.querySelector('.lightbox-close');
        const prevBtn = lightbox.querySelector('.lightbox-prev');
        const nextBtn = lightbox.querySelector('.lightbox-next');

        let currentIndex = 0;
        const images = [];

        galleryItems.forEach((item, index) => {
            const img = item.querySelector('img');
            const caption = item.querySelector('.gallery-overlay span');
            if (img) {
                images.push({
                    src: img.src,
                    alt: img.alt,
                    caption: caption ? caption.textContent : ''
                });
                item.addEventListener('click', () => openLightbox(index));
            }
        });

        function openLightbox(index) {
            currentIndex = index;
            updateLightbox();
            lightbox.classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function closeLightbox() {
            lightbox.classList.remove('active');
            document.body.style.overflow = '';
        }

        function updateLightbox() {
            const image = images[currentIndex];
            lightboxImg.src = image.src;
            lightboxImg.alt = image.alt;
            lightboxCaption.textContent = image.caption;
            prevBtn.style.display = images.length > 1 ? '' : 'none';
            nextBtn.style.display = images.length > 1 ? '' : 'none';
        }

        function prevImage() {
            currentIndex = (currentIndex - 1 + images.length) % images.length;
            updateLightbox();
        }

        function nextImage() {
            currentIndex = (currentIndex + 1) % images.length;
            updateLightbox();
        }

        const newCloseBtn = closeBtn.cloneNode(true);
        const newPrevBtn = prevBtn.cloneNode(true);
        const newNextBtn = nextBtn.cloneNode(true);
        closeBtn.replaceWith(newCloseBtn);
        prevBtn.replaceWith(newPrevBtn);
        nextBtn.replaceWith(newNextBtn);

        newCloseBtn.addEventListener('click', closeLightbox);
        newPrevBtn.addEventListener('click', prevImage);
        newNextBtn.addEventListener('click', nextImage);

        document.addEventListener('keydown', (e) => {
            if (!lightbox.classList.contains('active')) return;
            if (e.key === 'Escape') closeLightbox();
            if (e.key === 'ArrowLeft') prevImage();
            if (e.key === 'ArrowRight') nextImage();
        });

        lightbox.addEventListener('click', (e) => {
            if (e.target === lightbox) closeLightbox();
        });
    }

    initLightbox();
    setTimeout(initLightbox, 1500);
    setTimeout(initLightbox, 3000);
})();

/* ============ FLOATING FRANCHISE INQUIRY BUTTON ============ */
(function() {
    const overlay = document.createElement('div');
    overlay.className = 'float-modal-overlay';
    document.body.appendChild(overlay);

    const btn = document.createElement('button');
    btn.className = 'franchise-float-btn';
    btn.setAttribute('aria-label', 'Open franchise inquiry form');
    btn.innerHTML = `
        <span class="float-btn-icon">📋</span>
        <span class="float-btn-text">Apply for Franchise</span>
        <span class="franchise-float-tooltip">Apply for Franchise</span>
    `;
    document.body.appendChild(btn);

    const modal = document.createElement('div');
    modal.className = 'franchise-float-modal';
    modal.innerHTML = `
        <div class="float-modal-header">
            <h3>📋 Franchise Inquiry</h3>
            <button class="float-modal-close" aria-label="Close">&times;</button>
        </div>
        <div class="float-modal-body">
            <label class="form-field">
                <span class="field-label">Your Name</span>
                <input type="text" id="float-name" placeholder="e.g. Rahul Sharma" required>
            </label>
            <label class="form-field">
                <span class="field-label">Mobile Number</span>
                <input type="tel" id="float-mobile" placeholder="e.g. 9876543210" pattern="[6-9]{1}[0-9]{9}" maxlength="10" required>
            </label>
            <label class="form-field">
                <span class="field-label">Email Address</span>
                <input type="email" id="float-email" placeholder="e.g. rahul@example.com" required>
            </label>
            <label class="form-field">
                <span class="field-label">Preferred City</span>
                <input type="text" id="float-city" placeholder="e.g. Kanpur" required>
            </label>
            <label class="form-field">
                <span class="field-label">Budget Range</span>
                <select id="float-budget" required>
                    <option value="">Select your budget</option>
                    <option>Rs. 10-20 lakh</option>
                    <option>Rs. 20-35 lakh</option>
                    <option>Rs. 35 lakh+</option>
                </select>
            </label>
            <label class="form-field">
                <span class="field-label">Message (Optional)</span>
                <textarea id="float-message" rows="2" placeholder="Tell us about your location..."></textarea>
            </label>
            <button class="button primary form-submit-btn" type="submit" id="float-submit">
                <span class="btn-text">Submit Inquiry</span>
                <span class="btn-icon">→</span>
            </button>
            <div id="floatFormMessage" class="form-message" role="status"></div>
        </div>
    `;
    document.body.appendChild(modal);

    const closeBtn = modal.querySelector('.float-modal-close');
    const submitBtn = modal.querySelector('#float-submit');
    const formMessage = modal.querySelector('#floatFormMessage');

    function openModal() {
        modal.classList.add('active');
        overlay.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function closeModal() {
        modal.classList.remove('active');
        overlay.classList.remove('active');
        document.body.style.overflow = '';
    }

    btn.addEventListener('click', openModal);
    closeBtn.addEventListener('click', closeModal);
    overlay.addEventListener('click', closeModal);

    submitBtn.addEventListener('click', function() {
        const name = modal.querySelector('#float-name').value.trim();
        const mobile = modal.querySelector('#float-mobile').value.trim();
        const email = modal.querySelector('#float-email').value.trim();
        const city = modal.querySelector('#float-city').value.trim();
        const budget = modal.querySelector('#float-budget').value;
        const message = modal.querySelector('#float-message').value.trim();

        if (!name || name.length < 2) {
            formMessage.textContent = 'Please enter your name';
            formMessage.classList.add('show');
            return;
        }
        if (!/^[6-9]\d{9}$/.test(mobile)) {
            formMessage.textContent = 'Please enter a valid 10-digit mobile number';
            formMessage.classList.add('show');
            return;
        }
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            formMessage.textContent = 'Please enter a valid email address';
            formMessage.classList.add('show');
            return;
        }
        if (!city || city.length < 2) {
            formMessage.textContent = 'Please enter your preferred city';
            formMessage.classList.add('show');
            return;
        }
        if (!budget) {
            formMessage.textContent = 'Please select a budget range';
            formMessage.classList.add('show');
            return;
        }

        formMessage.className = 'form-message show';
        formMessage.innerHTML = `
            <span class="thank-emoji">🙏</span>
            <span class="thank-heading">Thank You, ${name}!</span>
            <span class="thank-detail">We'll contact you at <strong>${mobile}</strong> within 24 hours.</span>
        `;

        setTimeout(() => {
            formMessage.classList.remove('show');
            formMessage.textContent = '';
            modal.querySelectorAll('input, textarea, select').forEach(el => el.value = '');
            closeModal();
        }, 3000);
    });

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && modal.classList.contains('active')) {
            closeModal();
        }
    });
})();

/* ============ WHATSAPP FLOATING WIDGET ============ */
(function() {
    const whatsappNumber = '917081346666';
    const message = encodeURIComponent('Hi Grillista! I\'m interested in the franchise opportunity. Please share more details.');

    const widget = document.createElement('div');
    widget.className = 'whatsapp-widget';
    widget.innerHTML = `
        <a href="https://wa.me/${whatsappNumber}?text=${message}" 
           target="_blank" rel="noreferrer" 
           class="whatsapp-button" 
           aria-label="Chat on WhatsApp">
            <svg viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
            </svg>
            <span class="whatsapp-tooltip">Chat with us</span>
        </a>
    `;
    document.body.appendChild(widget);
})();

/* ============ COUNT-UP STATS ANIMATION ============ */
(function() {
    const statEls = document.querySelectorAll('.quick-stats strong');
    if (statEls.length === 0) return;

    const stats = [
        { element: statEls[0], target: 28, suffix: '+' },
        { element: statEls[1], target: 4, suffix: '' },
        { element: statEls[2], target: 15, suffix: '' },
        { element: statEls[3], target: 360, suffix: '' }
    ];

    stats.forEach(stat => {
        stat.element.textContent = '0' + stat.suffix;
    });

    let hasAnimated = false;

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting && !hasAnimated) {
                hasAnimated = true;
                animateCounts();
                observer.disconnect();
            }
        });
    }, { threshold: 0.5 });

    observer.observe(document.querySelector('.quick-stats'));

    function animateCounts() {
        const duration = 2000;
        const steps = 60;
        const interval = duration / steps;
        let currentStep = 0;

        const timer = setInterval(() => {
            currentStep++;
            const progress = Math.min(currentStep / steps, 1);
            const eased = 1 - Math.pow(1 - progress, 3);

            stats.forEach(stat => {
                const current = Math.round(eased * stat.target);
                stat.element.textContent = current + stat.suffix;
            });

            if (progress >= 1) {
                clearInterval(timer);
                stats.forEach(stat => {
                    stat.element.textContent = stat.target + stat.suffix;
                });
            }
        }, interval);
    }
})();

/* ============ BACK TO TOP BUTTON ============ */
(function() {
    const btn = document.createElement('button');
    btn.className = 'back-to-top';
    btn.setAttribute('aria-label', 'Back to top');
    btn.innerHTML = '&#8593;';
    document.body.appendChild(btn);

    window.addEventListener('scroll', () => {
        const scrollY = window.scrollY;
        if (scrollY > 400) {
            btn.classList.add('visible');
        } else {
            btn.classList.remove('visible');
        }
    }, { passive: true });

    btn.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
})();

/* ============ COMPREHENSIVE CLICK ANIMATIONS ============ */
(function() {
    function getRippleColor(el) {
        if (el.closest('.button.primary')) return 'ripple-red';
        if (el.closest('.button.secondary')) return 'ripple-dark';
        if (el.closest('.price-card.featured')) return 'ripple-white';
        if (el.closest('.price-card')) return 'ripple-green';
        if (el.closest('.contact-section, .lead-form')) return 'ripple-white';
        if (el.closest('.site-footer')) return 'ripple-white';
        if (el.closest('.gallery-item')) return 'ripple-white';
        if (el.closest('.social-link')) return 'ripple-white';
        if (el.closest('.nav-toggle')) return 'ripple-red';
        return 'ripple-red';
    }

    function getPressClass(el) {
        if (el.closest('.button')) return 'click-press';
        if (el.closest('.nav-toggle')) return 'click-press-light';
        if (el.closest('.back-to-top')) return 'click-press';
        if (el.closest('.social-link')) return 'click-press-light';
        return 'click-press-light';
    }

    function getFlashClass(el) {
        if (el.closest('.button.primary')) return 'click-flash';
        if (el.closest('.button.secondary')) return 'click-flash-green';
        if (el.closest('.price-card')) return 'click-flash-green';
        if (el.closest('.card-grid article')) return 'click-flash';
        if (el.closest('.gallery-item')) return 'click-flash';
        if (el.closest('.info-card')) return 'click-flash-green';
        return '';
    }

    function createRipple(e, el) {
        const ripple = document.createElement('span');
        ripple.className = 'ripple-effect ' + getRippleColor(el);
        const rect = el.getBoundingClientRect();
        const size = Math.max(el.offsetWidth, el.offsetHeight) * 0.4;
        ripple.style.width = ripple.style.height = size + 'px';
        ripple.style.left = (e.clientX - rect.left - size / 2) + 'px';
        ripple.style.top = (e.clientY - rect.top - size / 2) + 'px';
        
        const pos = window.getComputedStyle(el).position;
        if (pos === 'static') {
            el.style.position = 'relative';
        }
        el.style.overflow = 'hidden';
        el.appendChild(ripple);
        setTimeout(() => ripple.remove(), 700);
    }

    function applyPress(el, className) {
        el.classList.add(className);
        setTimeout(() => el.classList.remove(className), 300);
    }

    function applyFlash(el, className) {
        if (!className) return;
        el.classList.add(className);
        setTimeout(() => el.classList.remove(className), 400);
    }

    function applyBounce(el) {
        const isCard = el.closest('.card-grid article, .price-card, .testimonial-grid blockquote, .timeline article');
        if (isCard) {
            isCard.classList.add('click-bounce');
            setTimeout(() => isCard.classList.remove('click-bounce'), 500);
        }
    }

    const interactiveSelectors = [
        'a', 'button', '.button', 
        '.card-grid article', '.price-card', 
        '.testimonial-grid blockquote', '.timeline article',
        '.gallery-item', '.social-link', '.info-card',
        '.nav-toggle', '.back-to-top', '.outlet-dir',
        '.faq-list summary', '.contact-link', '.legal-link'
    ];

    document.addEventListener('click', function(e) {
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') return;
        
        let interactiveEl = null;
        for (const selector of interactiveSelectors) {
            const el = e.target.closest(selector);
            if (el) {
                interactiveEl = el;
                break;
            }
        }

        if (!interactiveEl) return;

        createRipple(e, interactiveEl);
        const pressClass = getPressClass(interactiveEl);
        applyPress(interactiveEl, pressClass);
        const flashClass = getFlashClass(interactiveEl);
        applyFlash(interactiveEl, flashClass);
        applyBounce(interactiveEl);
    });
})();

/* ============ 3D TILT EFFECT ON CARDS ============ */
(function() {
    const tiltCards = document.querySelectorAll('.card-grid article, .price-card, .testimonial-grid blockquote, .timeline article');
    
    tiltCards.forEach(card => {
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            const rotateX = (y - centerY) / centerY * -6;
            const rotateY = (x - centerX) / centerX * 6;
            card.style.transform = `perspective(800px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale(1.02)`;
            card.style.transition = 'transform 0.1s ease';
        });

        card.addEventListener('mouseleave', () => {
            card.style.transform = '';
            card.style.transition = 'transform 0.5s ease';
        });
    });
})();

/* ============ SPARKLE BURST ON BUTTON CLICK ============ */
(function() {
    function createSparkles(x, y) {
        const colors = ['#b82f26', '#e0a838', '#26624a', '#4caf50', '#fff'];
        for (let i = 0; i < 8; i++) {
            const sparkle = document.createElement('span');
            sparkle.className = 'sparkle-burst';
            const angle = (i / 8) * Math.PI * 2;
            const distance = 40 + Math.random() * 30;
            sparkle.style.left = x + 'px';
            sparkle.style.top = y + 'px';
            sparkle.style.setProperty('--dx', Math.cos(angle) * distance + 'px');
            sparkle.style.setProperty('--dy', Math.sin(angle) * distance + 'px');
            sparkle.style.background = colors[Math.floor(Math.random() * colors.length)];
            document.body.appendChild(sparkle);
            setTimeout(() => sparkle.remove(), 600);
        }
    }

    document.querySelectorAll('.button, .social-link, .outlet-dir').forEach(el => {
        el.addEventListener('click', (e) => {
            const rect = el.getBoundingClientRect();
            createSparkles(e.clientX || rect.left + rect.width / 2, e.clientY || rect.top + rect.height / 2);
        });
    });
})();

/* ============ SPLASH SCREEN ============ */
(function() {
    const splash = document.getElementById('splashScreen');
    if (!splash) return;
    
    setTimeout(() => {
        splash.classList.add('hidden');
        setTimeout(() => {
            splash.style.display = 'none';
        }, 600);
    }, 2000);
})();

/* ============ BLOG SLIDER ============ */
(function() {
    const slider = document.querySelector('.blog-featured-slider');
    if (!slider) return;

    const track = slider.querySelector('.blog-slider-track');
    const slides = slider.querySelectorAll('.blog-slide');
    const dots = slider.querySelectorAll('.blog-dot');
    const prevBtn = slider.querySelector('.blog-slider-prev');
    const nextBtn = slider.querySelector('.blog-slider-next');
    if (!track || slides.length === 0) return;

    let currentSlide = 0;
    let autoPlayInterval;

    function goToSlide(index) {
        currentSlide = index;
        track.style.transform = `translateX(-${currentSlide * 100}%)`;
        dots.forEach((dot, i) => {
            dot.classList.toggle('active', i === currentSlide);
        });
    }

    function nextSlide() {
        goToSlide((currentSlide + 1) % slides.length);
    }

    function prevSlide() {
        goToSlide((currentSlide - 1 + slides.length) % slides.length);
    }

    function startAutoPlay() {
        autoPlayInterval = setInterval(nextSlide, 5000);
    }

    function stopAutoPlay() {
        clearInterval(autoPlayInterval);
    }

    if (nextBtn) nextBtn.addEventListener('click', () => { stopAutoPlay(); nextSlide(); startAutoPlay(); });
    if (prevBtn) prevBtn.addEventListener('click', () => { stopAutoPlay(); prevSlide(); startAutoPlay(); });

    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => { stopAutoPlay(); goToSlide(index); startAutoPlay(); });
    });

    startAutoPlay();

    slider.addEventListener('mouseenter', stopAutoPlay);
    slider.addEventListener('mouseleave', startAutoPlay);

    let touchStartX = 0;
    track.addEventListener('touchstart', (e) => {
        touchStartX = e.changedTouches[0].screenX;
        stopAutoPlay();
    }, { passive: true });

    track.addEventListener('touchend', (e) => {
        const diff = touchStartX - e.changedTouches[0].screenX;
        if (Math.abs(diff) > 50) {
            if (diff > 0) nextSlide();
            else prevSlide();
        }
        startAutoPlay();
    }, { passive: true });
})();

/* ============ DARK MODE TOGGLE ============ */
(function() {
    const toggle = document.getElementById('darkToggle');
    if (!toggle) return;

    const saved = localStorage.getItem('grillista-dark-mode');
    if (saved === 'true') {
        document.body.classList.add('dark-mode');
        toggle.textContent = '☀️';
    }

    toggle.addEventListener('click', () => {
        const isDark = document.body.classList.toggle('dark-mode');
        toggle.textContent = isDark ? '☀️' : '🌙';
        localStorage.setItem('grillista-dark-mode', isDark);
    });
})();

/* ============ STICKY CTA ============ */
(function() {
    const stickyCta = document.getElementById('stickyCta');
    const footer = document.querySelector('.site-footer');
    if (!stickyCta || !footer) return;

    let ctaVisible = false;

    window.addEventListener('scroll', () => {
        const scrollY = window.scrollY;
        const footerTop = footer.getBoundingClientRect().top + window.scrollY;
        const windowHeight = window.innerHeight;
        
        const shouldShow = scrollY > windowHeight * 0.8 && (scrollY + windowHeight) < footerTop + 20;

        if (shouldShow && !ctaVisible) {
            stickyCta.classList.add('visible');
            ctaVisible = true;
        } else if (!shouldShow && ctaVisible) {
            stickyCta.classList.remove('visible');
            ctaVisible = false;
        }
    }, { passive: true });

    const backToTop = document.querySelector('.back-to-top');
    if (backToTop) {
        const observer = new MutationObserver(() => {
            if (stickyCta.classList.contains('visible')) {
                backToTop.style.bottom = '100px';
            } else {
                backToTop.style.bottom = '96px';
            }
        });
        observer.observe(stickyCta, { attributes: true, attributeFilter: ['class'] });
    }
})();

/* ============ TESTIMONIAL CAROUSEL ============ */
(function() {
    const testimonialSection = document.getElementById('testimonials');
    if (!testimonialSection) return;

    const grid = testimonialSection.querySelector('.testimonial-grid');
    if (!grid) return;

    const blocks = grid.querySelectorAll('blockquote');
    if (blocks.length <= 1) return;

    blocks.forEach(b => {
        b.classList.remove('animate-on-scroll', 'delay-1', 'delay-2', 'delay-3', 'visible');
        b.style.opacity = '1';
        b.style.transform = 'none';
    });

    grid.classList.remove('testimonial-grid');
    grid.classList.add('testimonial-carousel');

    const track = document.createElement('div');
    track.className = 'testimonial-track';

    blocks.forEach((block) => {
        const slide = document.createElement('div');
        slide.className = 'testimonial-slide';
        slide.appendChild(block);
        track.appendChild(slide);
    });

    grid.innerHTML = '';
    grid.appendChild(track);

    const prevBtn = document.createElement('button');
    prevBtn.className = 'carousel-btn carousel-prev';
    prevBtn.innerHTML = '&#8249;';
    prevBtn.setAttribute('aria-label', 'Previous testimonial');

    const nextBtn = document.createElement('button');
    nextBtn.className = 'carousel-btn carousel-next';
    nextBtn.innerHTML = '&#8250;';
    nextBtn.setAttribute('aria-label', 'Next testimonial');

    grid.appendChild(prevBtn);
    grid.appendChild(nextBtn);

    const dotsContainer = document.createElement('div');
    dotsContainer.className = 'testimonial-carousel-dots';

    const slides = track.querySelectorAll('.testimonial-slide');
    slides.forEach((_, index) => {
        const dot = document.createElement('button');
        dot.className = 'carousel-dot' + (index === 0 ? ' active' : '');
        dot.setAttribute('aria-label', `Go to testimonial ${index + 1}`);
        dot.addEventListener('click', () => goToSlide(index));
        dotsContainer.appendChild(dot);
    });

    grid.appendChild(dotsContainer);

    let currentSlide = 0;
    let autoPlayInterval;

    function goToSlide(index) {
        currentSlide = index;
        const slideWidth = slides[0].offsetWidth;
        track.style.transform = `translateX(-${currentSlide * slideWidth}px)`;
        
        const dots = dotsContainer.querySelectorAll('.carousel-dot');
        dots.forEach((dot, i) => {
            dot.classList.toggle('active', i === currentSlide);
        });
    }

    function nextSlide() {
        goToSlide((currentSlide + 1) % slides.length);
    }

    function prevSlide() {
        goToSlide((currentSlide - 1 + slides.length) % slides.length);
    }

    nextBtn.addEventListener('click', nextSlide);
    prevBtn.addEventListener('click', prevSlide);

    function startAutoPlay() {
        autoPlayInterval = setInterval(nextSlide, 5000);
    }

    function stopAutoPlay() {
        clearInterval(autoPlayInterval);
    }

    startAutoPlay();
    grid.addEventListener('mouseenter', stopAutoPlay);
    grid.addEventListener('mouseleave', startAutoPlay);

    let resizeTimeout;
    window.addEventListener('resize', () => {
        clearTimeout(resizeTimeout);
        resizeTimeout = setTimeout(() => {
            goToSlide(currentSlide);
        }, 200);
    });

    let touchStartX = 0;
    let touchEndX = 0;

    track.addEventListener('touchstart', (e) => {
        touchStartX = e.changedTouches[0].screenX;
        stopAutoPlay();
    }, { passive: true });

    track.addEventListener('touchend', (e) => {
        touchEndX = e.changedTouches[0].screenX;
        const diff = touchStartX - touchEndX;
        if (Math.abs(diff) > 50) {
            if (diff > 0) nextSlide();
            else prevSlide();
        }
        startAutoPlay();
    }, { passive: true });
})();

/* ============ FORM VALIDATION WITH REAL-TIME FEEDBACK ============ */
(function() {
    const form = document.getElementById('franchiseForm');
    if (!form) return;

    const fields = [
        { id: 'name', validate: (v) => v.trim().length >= 2, error: 'Name must be at least 2 characters' },
        { id: 'mobile', validate: (v) => /^[6-9]\d{9}$/.test(v.trim()), error: 'Enter a valid 10-digit mobile number' },
        { id: 'email', validate: (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim()), error: 'Enter a valid email address' },
        { id: 'city', validate: (v) => v.trim().length >= 2, error: 'City name is required' },
        { id: 'budget', validate: (v) => v !== '', error: 'Please select a budget range' }
    ];

    fields.forEach(field => {
        const input = document.getElementById(field.id);
        if (!input || input.tagName === 'SELECT') return;

        const feedback = document.createElement('span');
        feedback.className = 'field-feedback';
        input.parentNode.appendChild(feedback);

        input.addEventListener('blur', () => {
            validateField(field);
        });

        input.addEventListener('input', () => {
            if (input.dataset.touched === 'true') {
                validateField(field);
            }
        });

        input.addEventListener('focus', () => {
            input.dataset.touched = 'true';
        });
    });

    const budgetSelect = document.getElementById('budget');
    if (budgetSelect) {
        const budgetLabel = budgetSelect.closest('label');
        const feedback = document.createElement('span');
        feedback.className = 'field-feedback';
        budgetLabel.appendChild(feedback);

        const budgetField = fields.find(f => f.id === 'budget');
        budgetSelect.addEventListener('change', () => {
            budgetSelect.dataset.touched = 'true';
            if (budgetField) validateField(budgetField);
        });
        budgetSelect.addEventListener('focus', () => {
            budgetSelect.dataset.touched = 'true';
        });
    }

    function validateField(field) {
        const input = document.getElementById(field.id);
        if (!input) return;

        const value = input.tagName === 'SELECT' ? input.value : input.value;
        const isValid = field.validate(value);
        
        const parent = input.closest('label');
        const feedback = parent ? parent.querySelector('.field-feedback') : null;

        if (isValid) {
            input.classList.remove('error');
            input.classList.add('valid');
            if (feedback) {
                feedback.className = 'field-feedback show success-text';
                feedback.textContent = '✓ Looks good!';
            }
        } else {
            input.classList.remove('valid');
            if (value.length > 0 || input.dataset.touched === 'true') {
                input.classList.add('error');
                if (feedback) {
                    feedback.className = 'field-feedback show error-text';
                    feedback.textContent = field.error;
                }
            } else {
                input.classList.remove('error');
                if (feedback) {
                    feedback.className = 'field-feedback';
                }
            }
        }

        return isValid;
    }

    form.addEventListener('submit', function(e) {
        let allValid = true;
        fields.forEach(field => {
            const input = document.getElementById(field.id);
            if (input) input.dataset.touched = 'true';
            
            if (!validateField(field)) {
                allValid = false;
            }
        });

        if (!allValid) {
            e.preventDefault();
            const firstError = form.querySelector('.error');
            if (firstError) {
                firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
                firstError.focus();
            }
        }
    }, true);
})();

/* ============ MOBILE RESPONSIVENESS - ADDITIONAL IMPROVEMENTS ============ */
(function() {
    const setVH = () => {
        const vh = window.innerHeight * 0.01;
        document.documentElement.style.setProperty('--vh', `${vh}px`);
    };
    setVH();
    window.addEventListener('resize', setVH);

    const hero = document.querySelector('.hero');
    if (hero) {
        const updateHeroHeight = () => {
            if (window.innerWidth <= 620) {
                hero.style.minHeight = `calc(var(--vh, 1vh) * 88)`;
            } else {
                hero.style.minHeight = '';
            }
        };
        updateHeroHeight();
        window.addEventListener('resize', updateHeroHeight);
    }

    if ('ontouchstart' in window) {
        document.querySelectorAll('.main-nav a').forEach(link => {
            link.style.padding = '14px 12px';
        });
    }

    const brand = document.querySelector('.brand');
    if (brand) {
        brand.addEventListener('click', (e) => {
            e.preventDefault();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }
})();

/* ============ SMOOTH SCROLL FOR ALL ANCHOR LINKS ============ */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        const targetId = this.getAttribute('href');
        if (targetId === '#') return;
        const target = document.querySelector(targetId);
        if (target) {
            e.preventDefault();
            const headerOffset = 90;
            const elementPosition = target.getBoundingClientRect().top;
            const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

            window.scrollTo({
                top: offsetPosition,
                behavior: 'smooth'
            });
        }
    });
});